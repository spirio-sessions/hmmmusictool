x = 1
if x == 1:
    # indented four spaces
    print("x is 1.")
